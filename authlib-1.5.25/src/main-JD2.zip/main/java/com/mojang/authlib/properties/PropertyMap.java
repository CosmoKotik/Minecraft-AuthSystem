package com.mojang.authlib.properties;

import com.google.common.collect.ForwardingMultimap;
import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Multimap;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.Map;

public class PropertyMap extends ForwardingMultimap<String, Property> {
  private final Multimap<String, Property> properties = (Multimap<String, Property>)LinkedHashMultimap.create();
  
  protected Multimap<String, Property> delegate() {
    return this.properties;
  }
  
  public static class Serializer implements JsonSerializer<PropertyMap>, JsonDeserializer<PropertyMap> {
    public PropertyMap deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
      PropertyMap result = new PropertyMap();
      if (json instanceof JsonObject) {
        JsonObject object = (JsonObject)json;
        Iterator<Map.Entry> var6 = object.entrySet().iterator();
        while (true) {
          if (!var6.hasNext())
            return result; 
          Map.Entry entry = var6.next();
          if (entry.getValue() instanceof JsonArray) {
            Iterator<JsonElement> var8 = ((JsonArray)entry.getValue()).iterator();
            while (var8.hasNext()) {
              JsonElement element = var8.next();
              result.put(entry.getKey(), new Property((String)entry.getKey(), element.getAsString()));
            } 
          } 
        } 
      } 
      if (json instanceof JsonArray) {
        Iterator<JsonElement> var10 = ((JsonArray)json).iterator();
        while (var10.hasNext()) {
          JsonElement element = var10.next();
          if (element instanceof JsonObject) {
            JsonObject object = (JsonObject)element;
            String name = object.getAsJsonPrimitive("name").getAsString();
            String value = object.getAsJsonPrimitive("value").getAsString();
            if (object.has("signature")) {
              result.put(name, new Property(name, value, object.getAsJsonPrimitive("signature").getAsString()));
              continue;
            } 
            result.put(name, new Property(name, value));
          } 
        } 
      } 
      return result;
    }
    
    public JsonElement serialize(PropertyMap src, Type typeOfSrc, JsonSerializationContext context) {
      JsonArray result = new JsonArray();
      for (Iterator<Property> var5 = src.values().iterator(); var5.hasNext(); result.add((JsonElement)object)) {
        Property property = var5.next();
        JsonObject object = new JsonObject();
        object.addProperty("name", property.getName());
        object.addProperty("value", property.getValue());
        if (property.hasSignature())
          object.addProperty("signature", property.getSignature()); 
      } 
      return (JsonElement)result;
    }
  }
}
